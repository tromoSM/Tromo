This theory is made by tromoSM.
All the visuals are made by tromoSM in microsoft powerpoint.
The theory is about traveling between alternate realities through dimension of time.
2025 06 28  6.28AM As YYYY MM DD  H.MMTT

© All right reserved - 2025 tromoSM 